#![no_std]
#![no_main]

use core::panic::PanicInfo;
use oneos_app::{console_read, console_write_line, console_write_str, watchdog_feed, AppApiV1};

/// Panic handler: loop forever. oneOS apps abort on panic.
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}

/// Entry point for the chatbot application.
///
/// This is a rule‐based English chatbot for oneOS. It supports
/// remembering the user's name, responding to simple feelings, storing
/// topics the user likes, evaluating arithmetic expressions, and
/// providing helpful fallbacks when no specific rule matches.
#[no_mangle]
pub extern "C" fn oneos_app_main(api: *const AppApiV1) -> i32 {
    unsafe {
        console_write_line(api, "oneOS Chatbot - advanced");
        console_write_line(api, "Type 'help' for commands and 'bye' to exit.");
    }

    // Memory: name, feelings and topics.
    let mut name: [u8; 24] = [0; 24];
    let mut name_len: usize = 0;
    let mut last_feeling = Feeling::None;
    let mut topics: [[u8; 20]; 5] = [[0; 20]; 5];
    let mut topics_count: usize = 0;

    // Buffers for input and normalized input.
    let mut buf: [u8; 128] = [0; 128];
    let mut norm: [u8; 128] = [0; 128];

    loop {
        // Feed watchdog each loop to satisfy the global app timeout policy.
        unsafe { watchdog_feed(api) };
        // Prompt user
        unsafe {
            console_write_str(api, "\n> ");
        }
        // Read a line from the console. Non‑blocking reads return 0 or negative.
        let n = unsafe { console_read(api, &mut buf) };
        if n <= 0 {
            unsafe { watchdog_feed(api) };
            // No input available; skip to next iteration. In a proper OS this
            // would block, but for now we just continue.
            continue;
        }
        let line = normalize(&buf[..n as usize], &mut norm);
        if line.is_empty() {
            continue;
        }

        // Exit
        if eq(line, "bye") || eq(line, "exit") || eq(line, "quit") {
            unsafe {
                console_write_line(api, "Goodbye.");
            }
            break;
        }

        // Help command
        if eq(line, "help") || eq(line, "h") || eq(line, "commands") {
            unsafe {
                console_write_line(api, "Available commands:");
                console_write_line(api, "  hello/hi    – greet the bot");
                console_write_line(api, "  my name is <name> – tell me your name");
                console_write_line(api, "  what is my name – ask me to recall your name");
                console_write_line(api, "  i feel <emotion> – share how you feel");
                console_write_line(api, "  because <reason> – explain your feeling");
                console_write_line(api, "  i like <topic> – tell me something you like");
                console_write_line(api, "  what do i like – ask me to recall what you like");
                console_write_line(api, "  calc <expr> – evaluate arithmetic (numbers + - * /)");
                console_write_line(api, "  what can you do – see my capabilities");
                console_write_line(api, "  bye/exit/quit – exit the chatbot");
            }
            continue;
        }

        // Greetings
        if contains(line, "hello") || contains(line, "hi") || contains(line, "hey") {
            unsafe {
                if name_len > 0 {
                    console_write_str(api, "Hello, ");
                    write_bytes(api, &name[..name_len]);
                    console_write_line(api, ".");
                } else {
                    console_write_line(api, "Hello. I am OneOS-Bot.");
                }
            }
            continue;
        }

        // Remember name
        if let Some(rest) = strip_prefix(line, "my name is") {
            let rest = trim(rest);
            if !rest.is_empty() {
                name_len = copy(&mut name, rest);
                unsafe {
                    console_write_str(api, "Nice to meet you, ");
                    write_bytes(api, &name[..name_len]);
                    console_write_line(api, ".");
                }
            } else {
                unsafe { console_write_line(api, "Please tell me your name after 'my name is'."); }
            }
            continue;
        }

        // Recall name
        if contains(line, "what is my name") {
            unsafe {
                if name_len == 0 {
                    console_write_line(api, "I do not know your name yet.");
                } else {
                    console_write_str(api, "Your name is ");
                    write_bytes(api, &name[..name_len]);
                    console_write_line(api, ".");
                }
            }
            continue;
        }

        // Feelings: "i feel <emotion>" or "i am <emotion>"
        if let Some(rest) = strip_prefix(line, "i feel") {
            handle_feeling(api, trim(rest), &mut last_feeling);
            continue;
        }
        if let Some(rest) = strip_prefix(line, "i am") {
            handle_feeling(api, trim(rest), &mut last_feeling);
            continue;
        }

        // Explanation of feeling with "because"
        if contains(line, "because") {
            match last_feeling {
                Feeling::Sad => unsafe {
                    console_write_line(api, "It can be tough when that happens. I'm here to listen.");
                },
                Feeling::Happy => unsafe {
                    console_write_line(api, "That's wonderful to hear!");
                },
                Feeling::Tired => unsafe {
                    console_write_line(api, "Make sure to rest and take care of yourself.");
                },
                Feeling::Angry => unsafe {
                    console_write_line(api, "Try to take deep breaths and calm down.");
                },
                Feeling::Bored => unsafe {
                    console_write_line(api, "Maybe try something new and exciting.");
                },
                Feeling::Anxious => unsafe {
                    console_write_line(api, "Talking about it might help alleviate anxiety.");
                },
                Feeling::Excited => unsafe {
                    console_write_line(api, "Sounds really exciting!");
                },
                Feeling::Unknown => unsafe {
                    console_write_line(api, "I see. Tell me more about how you feel.");
                },
                Feeling::None => unsafe {
                    console_write_line(api, "I see.");
                },
            }
            continue;
        }

        // Interests: "i like <topic>" or "i love <topic>"
        if let Some(rest) = strip_prefix(line, "i like") {
            handle_like(api, trim(rest), &mut topics, &mut topics_count);
            continue;
        }
        if let Some(rest) = strip_prefix(line, "i love") {
            handle_like(api, trim(rest), &mut topics, &mut topics_count);
            continue;
        }

        // Recall interests
        if contains(line, "what do i like") {
            handle_what_do_i_like(api, &topics, topics_count);
            continue;
        }

        // Arithmetic evaluation: "calc <expr>", "calculate <expr>", "compute <expr>"
        if let Some(expr) = strip_prefix(line, "calc") {
            handle_calc(api, trim(expr));
            continue;
        }
        if let Some(expr) = strip_prefix(line, "calculate") {
            handle_calc(api, trim(expr));
            continue;
        }
        if let Some(expr) = strip_prefix(line, "compute") {
            handle_calc(api, trim(expr));
            continue;
        }

        // Capabilities
        if contains(line, "what can you do") {
            unsafe {
                console_write_line(api, "I can chat, remember your name, respond to feelings, remember things you like, and evaluate simple arithmetic expressions.");
            }
            continue;
        }

        // Fallback reflective response
        reflective_fallback(api, line);
    }

    0
}

/// Enum representing the last emotion the user expressed. It can be used to
/// adjust responses when the user provides a reason with "because".
#[derive(Copy, Clone, PartialEq, Eq)]
enum Feeling {
    None,
    Sad,
    Happy,
    Tired,
    Angry,
    Bored,
    Anxious,
    Excited,
    Unknown,
}

/// Normalize an input string by converting ASCII letters to lowercase,
/// converting all punctuation characters into spaces, and preserving
/// digits and spaces. Returns a trimmed slice of the provided output
/// buffer without leading or trailing spaces. The output slice
/// references `out` and must not outlive it.
fn normalize<'a>(input: &[u8], out: &'a mut [u8]) -> &'a [u8] {
    let mut n = 0usize;
    for &b in input {
        let c = match b {
            b'A'..=b'Z' => b + 32,          // uppercase to lowercase
            b'a'..=b'z' | b'0'..=b'9' | b' ' => b, // keep letters, digits, spaces
            _ => b' ',                       // convert punctuation to space
        };
        if n < out.len() {
            out[n] = c;
            n += 1;
        }
    }
    trim(&out[..n])
}

/// Remove leading and trailing spaces from a byte slice.
fn trim(mut s: &[u8]) -> &[u8] {
    while !s.is_empty() && s[0] == b' ' {
        s = &s[1..];
    }
    while !s.is_empty() && s[s.len() - 1] == b' ' {
        s = &s[..s.len() - 1];
    }
    s
}

/// Check if two ASCII slices are equal.
fn eq(s: &[u8], w: &str) -> bool {
    s == w.as_bytes()
}

/// Determine if the haystack contains the needle as a substring.
fn contains(hay: &[u8], needle: &str) -> bool {
    find(hay, needle.as_bytes()).is_some()
}

/// Find the first occurrence of a subslice in a haystack.
fn find(hay: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() {
        return Some(0);
    }
    if hay.len() < needle.len() {
        return None;
    }
    for i in 0..=hay.len() - needle.len() {
        if &hay[i..i + needle.len()] == needle {
            return Some(i);
        }
    }
    None
}

/// Strip a prefix from a byte slice if present. The prefix must match
/// exactly (no extra trimming). Returns the remainder of the slice
/// following the prefix or None if not matched.
fn strip_prefix<'a>(s: &'a [u8], prefix: &str) -> Option<&'a [u8]> {
    let p = prefix.as_bytes();
    if s.len() >= p.len() && &s[..p.len()] == p {
        Some(&s[p.len()..])
    } else {
        None
    }
}

/// Copy characters from `src` into `dst` (skipping spaces) until
/// either `dst` is full or `src` is exhausted. Returns the number of
/// bytes written.
fn copy(dst: &mut [u8], src: &[u8]) -> usize {
    let mut i = 0usize;
    for &b in src {
        if b == b' ' { continue; }
        if i < dst.len() {
            dst[i] = b;
            i += 1;
        } else {
            break;
        }
    }
    i
}

/// Write a slice of bytes to the console one byte at a time via
/// console_write_str. Assumes UTF‑8 and that `api` is valid.
unsafe fn write_bytes(api: *const AppApiV1, bytes: &[u8]) {
    for &ch in bytes {
        let s = core::str::from_utf8_unchecked(core::slice::from_ref(&ch));
        console_write_str(api, s);
    }
}

/// Handle feelings expressed by the user. Parses the first word as an
/// emotion, updates the `last_feeling` and produces an appropriate
/// response.
fn handle_feeling(api: *const AppApiV1, rest: &[u8], last_feeling: &mut Feeling) {
    let mut it = rest.iter().copied().peekable();
    // Extract the first word (stop at space)
    let mut word = [0u8; 16];
    let mut wlen = 0usize;
    while let Some(&b) = it.peek() {
        if b == b' ' { break; }
        if wlen < word.len() {
            word[wlen] = b;
            wlen += 1;
        }
        it.next();
    }
    // Interpret the emotion
    let emotion = match &word[..wlen] {
        b"sad" => Feeling::Sad,
        b"happy" => Feeling::Happy,
        b"tired" => Feeling::Tired,
        b"angry" => Feeling::Angry,
        b"bored" => Feeling::Bored,
        b"anxious" => Feeling::Anxious,
        b"excited" => Feeling::Excited,
        _ => Feeling::Unknown,
    };
    *last_feeling = emotion;
    unsafe {
        match emotion {
            Feeling::Sad => {
                console_write_line(api, "I'm sorry to hear that. What happened?");
            }
            Feeling::Happy => {
                console_write_line(api, "That's great! What's making you happy?");
            }
            Feeling::Tired => {
                console_write_line(api, "Maybe you need some rest.");
            }
            Feeling::Angry => {
                console_write_line(api, "Try to stay calm and take deep breaths.");
            }
            Feeling::Bored => {
                console_write_line(api, "Maybe find a fun activity to do.");
            }
            Feeling::Anxious => {
                console_write_line(api, "It's okay to feel anxious sometimes. Is something bothering you?");
            }
            Feeling::Excited => {
                console_write_line(api, "That sounds exciting!");
            }
            Feeling::Unknown => {
                console_write_line(api, "Tell me more about how you feel.");
            }
            Feeling::None => {
                // Should not happen as None isn't set here
            }
        }
    }
}

/// Check if a given topic already exists in the topics list.
fn topic_exists(topics: &[[u8; 20]; 5], count: usize, topic: &[u8]) -> bool {
    for i in 0..count {
        let t = &topics[i];
        // Determine length of stored topic
        let mut tlen = 0usize;
        while tlen < t.len() && t[tlen] != 0 { tlen += 1; }
        if tlen == topic.len() && &t[..tlen] == topic {
            return true;
        }
    }
    false
}

/// Handle "i like <topic>" or "i love <topic>" statements. Stores
/// the topic in the topics list if new and prints an acknowledgment.
fn handle_like(api: *const AppApiV1, rest: &[u8], topics: &mut [[u8; 20]; 5], count: &mut usize) {
    let rest = rest;
    // Extract the first word (topic) until a space
    let mut topic_buf = [0u8; 20];
    let mut tlen = 0usize;
    for &b in rest {
        if b == b' ' { break; }
        if tlen < topic_buf.len() {
            topic_buf[tlen] = b;
            tlen += 1;
        }
    }
    if tlen == 0 {
        unsafe { console_write_line(api, "Tell me something you like after 'i like'."); }
        return;
    }
    let topic = &topic_buf[..tlen];
    if topic_exists(topics, *count, topic) {
        unsafe {
            console_write_str(api, "You already told me you like ");
            write_bytes(api, topic);
            console_write_line(api, ".");
        }
    } else {
        if *count < topics.len() {
            // store new topic
            for j in 0..tlen { topics[*count][j] = topic[j]; }
            // zero out the rest
            for j in tlen..topics[*count].len() { topics[*count][j] = 0; }
            *count += 1;
            unsafe {
                console_write_str(api, "Oh nice, I'll remember that you like ");
                write_bytes(api, topic);
                console_write_line(api, ".");
            }
        } else {
            unsafe {
                console_write_str(api, "I remember that you like ");
                write_bytes(api, topic);
                console_write_line(api, ", but my memory is full.");
            }
        }
    }
}

/// Handle "what do i like" queries. Prints the list of topics stored.
fn handle_what_do_i_like(api: *const AppApiV1, topics: &[[u8; 20]; 5], count: usize) {
    if count == 0 {
        unsafe {
            console_write_line(api, "I don't know what you like yet. Tell me something you like.");
        }
        return;
    }
    unsafe {
        console_write_str(api, "You mentioned that you like ");
    }
    // Print topics separated by comma and 'and' for the last
    for i in 0..count {
        let topic = &topics[i];
        // compute length
        let mut len = 0usize;
        while len < topic.len() && topic[len] != 0 { len += 1; }
        if len > 0 {
            unsafe { write_bytes(api, &topic[..len]); }
            if i + 2 == count {
                // second last: add ' and '
                unsafe { console_write_str(api, " and "); }
            } else if i + 1 < count {
                unsafe { console_write_str(api, ", "); }
            }
        }
    }
    unsafe { console_write_line(api, "."); }
}

/// Handle arithmetic evaluation. Evaluates the expression with integer
/// operations and prints the result or an error message.
fn handle_calc(api: *const AppApiV1, expr: &[u8]) {
    if expr.is_empty() {
        unsafe { console_write_line(api, "Usage: calc <expression>"); }
        return;
    }
    match eval_expr_i64(expr) {
        Ok(v) => unsafe {
            console_write_str(api, "Result: ");
            write_i64(api, v);
            console_write_line(api, ".");
        },
        Err(_) => unsafe {
            console_write_line(api, "Invalid expression. Please use numbers with +, -, *, / and no parentheses.");
        },
    }
}

/// Provide a reflective fallback response when no rule matches. Uses a
/// simple checksum of the input to select a response variation.
fn reflective_fallback(api: *const AppApiV1, line: &[u8]) {
    // compute a simple checksum to pick a variation
    let mut sum: u32 = 0;
    for &b in line {
        sum = sum.wrapping_add(b as u32);
    }
    let variant = sum % 3;
    unsafe {
        match variant {
            0 => console_write_line(api, "Can you tell me more about that?"),
            1 => console_write_line(api, "Why do you say that?"),
            _ => console_write_line(api, "What makes you feel that way?"),
        };
    }
}

/* Arithmetic parser from the earlier simple calculator implementation */

fn eval_expr_i64(s: &[u8]) -> Result<i64, ()> {
    let mut p = 0usize;
    let mut v = parse_term(s, &mut p)?;
    loop {
        skip_spaces(s, &mut p);
        if p >= s.len() { break; }
        let op = s[p];
        if op != b'+' && op != b'-' { break; }
        p += 1;
        let rhs = parse_term(s, &mut p)?;
        v = if op == b'+' { v.saturating_add(rhs) } else { v.saturating_sub(rhs) };
    }
    skip_spaces(s, &mut p);
    if p != s.len() { return Err(()); }
    Ok(v)
}

fn parse_term(s: &[u8], p: &mut usize) -> Result<i64, ()> {
    let mut v = parse_factor(s, p)?;
    loop {
        skip_spaces(s, p);
        if *p >= s.len() { break; }
        let op = s[*p];
        if op != b'*' && op != b'/' { break; }
        *p += 1;
        let rhs = parse_factor(s, p)?;
        v = if op == b'*' {
            v.saturating_mul(rhs)
        } else {
            if rhs == 0 { return Err(()); }
            v / rhs
        };
    }
    Ok(v)
}

fn parse_factor(s: &[u8], p: &mut usize) -> Result<i64, ()> {
    skip_spaces(s, p);
    if *p >= s.len() { return Err(()); }
    let mut sign: i64 = 1;
    if s[*p] == b'+' {
        *p += 1;
    } else if s[*p] == b'-' {
        *p += 1;
        sign = -1;
    }
    skip_spaces(s, p);
    let mut any = false;
    let mut v: i64 = 0;
    while *p < s.len() {
        let b = s[*p];
        if !(b'0'..=b'9').contains(&b) { break; }
        any = true;
        v = v.saturating_mul(10).saturating_add((b - b'0') as i64);
        *p += 1;
    }
    if !any { return Err(()); }
    Ok(v.saturating_mul(sign))
}

fn skip_spaces(s: &[u8], p: &mut usize) {
    while *p < s.len() && (s[*p] == b' ' || s[*p] == b'\t') {
        *p += 1;
    }
}

/// Write a signed 64‑bit integer to the console.
unsafe fn write_i64(api: *const AppApiV1, v: i64) {
    if v < 0 {
        console_write_str(api, "-");
        write_u64(api, (-v) as u64);
    } else {
        write_u64(api, v as u64);
    }
}

/// Write an unsigned 64‑bit integer to the console.
unsafe fn write_u64(api: *const AppApiV1, mut v: u64) {
    let mut tmp = [0u8; 20];
    let mut i = 0usize;
    if v == 0 {
        tmp[0] = b'0';
        i = 1;
    } else {
        while v != 0 && i < tmp.len() {
            tmp[i] = b'0' + (v % 10) as u8;
            v /= 10;
            i += 1;
        }
    }
    for ch in tmp[..i].iter().rev() {
        let s = core::str::from_utf8_unchecked(core::slice::from_ref(ch));
        console_write_str(api, s);
    }
}
